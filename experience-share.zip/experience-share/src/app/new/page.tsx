import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createPost } from "@/app/actions";

export default async function NewPostPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const sp = await searchParams;
  const errorMsg = sp?.error;

  if (!user) {
    return (
      <div className="rounded-lg border border-zinc-200 bg-white p-6">
        <h1 className="text-xl font-semibold">เขียนโพสต์</h1>
        <p className="mt-2 text-sm text-zinc-600">
          ต้องเข้าสู่ระบบก่อนถึงจะเขียนโพสต์ได้ครับ
        </p>
        <div className="mt-4">
          <Link href="/" className="text-sm font-medium text-zinc-900 underline">
            กลับไปหน้าแรก
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">เขียนโพสต์</h1>
        <p className="mt-1 text-sm text-zinc-600">
          แชร์ประสบการณ์ของคุณให้คนอื่นมาอ่านและคอมเมนต์ได้
        </p>
      </div>

      {errorMsg ? (
        <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {errorMsg}
        </div>
      ) : null}

      <form
        action={createPost}
        className="rounded-lg border border-zinc-200 bg-white p-6"
      >
        <label className="block">
          <span className="text-sm font-medium">หัวข้อ</span>
          <input
            name="title"
            required
            maxLength={120}
            className="mt-1 w-full rounded-md border border-zinc-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-zinc-900/10"
            placeholder="เช่น ประสบการณ์ทำงานที่แรกของผม"
          />
        </label>

        <label className="mt-4 block">
          <span className="text-sm font-medium">เนื้อหา</span>
          <textarea
            name="content"
            required
            rows={10}
            className="mt-1 w-full rounded-md border border-zinc-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-zinc-900/10"
            placeholder="เล่าให้เต็มที่ได้เลย..."
          />
        </label>

        <div className="mt-5 flex items-center justify-between gap-3">
          <Link href="/" className="text-sm text-zinc-600 hover:text-zinc-900">
            ยกเลิก
          </Link>
          <button
            type="submit"
            className="rounded-md bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-800"
          >
            โพสต์
          </button>
        </div>
      </form>
    </div>
  );
}
