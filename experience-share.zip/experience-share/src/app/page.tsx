import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import type { Post } from "@/lib/db-types";

function formatDate(iso: string) {
  return new Date(iso).toLocaleString("th-TH", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

export default function Home() {
  return <HomeImpl />;
}

async function HomeImpl() {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("posts")
    .select("id,user_id,author_name,author_avatar_url,title,content,created_at")
    .order("created_at", { ascending: false })
    .limit(30);

  const posts = (data ?? []) as Post[];

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">ฟีดประสบการณ์</h1>
          <p className="mt-1 text-sm text-zinc-600">
            แชร์เรื่องราว ประสบการณ์ และให้คนอื่นคอมเมนต์/รีวิว/ตอบกลับได้
          </p>
        </div>
        <Link
          href="/new"
          className="rounded-md bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-800"
        >
          เขียนโพสต์
        </Link>
      </div>

      {error ? (
        <div className="rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          โหลดข้อมูลไม่สำเร็จ: {error.message}
        </div>
      ) : null}

      <div className="space-y-4">
        {posts.length === 0 ? (
          <div className="rounded-md border border-zinc-200 bg-white p-6 text-sm text-zinc-600">
            ยังไม่มีโพสต์ ลองกด “เขียนโพสต์” เพื่อเริ่มต้นได้เลย
          </div>
        ) : (
          posts.map((p) => (
            <Link
              key={p.id}
              href={`/post/${p.id}`}
              className="block rounded-lg border border-zinc-200 bg-white p-5 hover:bg-zinc-50"
            >
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-lg font-semibold">{p.title}</h2>
                <span className="shrink-0 text-xs text-zinc-500">
                  {formatDate(p.created_at)}
                </span>
              </div>
              <p className="mt-2 max-h-12 overflow-hidden text-sm text-zinc-700">
                {p.content}
              </p>
              <div className="mt-3 text-xs text-zinc-500">
                โดย {p.author_name ?? "ผู้ใช้"}
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
